<?php
// Include database connection
include_once '../common/db.php';

// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Determine the type of request
$type = $_GET['type'] ?? '';

if ($type === 'notices') {
    try {
        // Fetch notices
        $query = "SELECT id, title, content, DATE_FORMAT(created_at, '%d-%b-%Y') as created_at FROM notices ORDER BY created_at DESC";
        $result = $conn->query($query);

        $notices = [];
        while ($row = $result->fetch_assoc()) {
            $notices[] = $row;
        }

        echo json_encode(['status' => 'success', 'data' => $notices]);
    } catch (Exception $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(['status' => 'error', 'message' => 'Failed to fetch notices', 'error' => $e->getMessage()]);
    }
} elseif ($type === 'holidays') {
    try {
        // Fetch holidays
        $query = "SELECT id, holiday_name, DATE_FORMAT(holiday_date, '%d-%b-%Y') as holiday_date FROM holidays ORDER BY holiday_date ASC";
        $result = $conn->query($query);

        $holidays = [];
        while ($row = $result->fetch_assoc()) {
            $holidays[] = $row;
        }

        echo json_encode(['status' => 'success', 'data' => $holidays]);
    } catch (Exception $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(['status' => 'error', 'message' => 'Failed to fetch holidays', 'error' => $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid request type']);
}
?>
