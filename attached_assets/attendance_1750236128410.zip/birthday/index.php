<?php
header("Content-Type: application/json");

// Include the database connection
include_once '../common/db.php'; // Ensure this file correctly initializes `$conn` // or your actual DB connection path

$response = [];

$sql = "SELECT emp_no, name, dob, gender, designation 
        FROM employees 
        WHERE DATE_FORMAT(dob, '%m-%d') = DATE_FORMAT(CURDATE(), '%m-%d')";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $birthdays = [];
    while ($row = $result->fetch_assoc()) {
        $birthdays[] = [
            'emp_no' => $row['emp_no'],
            'name' => $row['name'],
            'dob' => date('d-M-Y', strtotime($row['dob'])),
            'gender' => $row['gender'],
            'designation' => $row['designation']
        ];
    }

    $response = [
        'status' => true,
        'message' => 'Birthday(s) found today!',
        'data' => $birthdays
    ];
} else {
    $response = [
        'status' => false,
        'message' => 'No birthdays today',
        'data' => []
    ];
}

echo json_encode($response);
$conn->close();
?>
