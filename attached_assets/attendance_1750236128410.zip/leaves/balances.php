<?php
// Include database connection
include_once '../common/db.php';

// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Get emp_no from query parameters
$emp_no = $_GET['emp_no'] ?? '';

if (empty($emp_no)) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Employee number is required.']);
    exit;
}

try {
    // Validate if employee exists
    $check_query = "SELECT COUNT(*) AS count FROM employees WHERE emp_no = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param('s', $emp_no);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result()->fetch_assoc();
    if ($check_result['count'] == 0) {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'Employee not found.']);
        exit;
    }
    $check_stmt->close();

    // Query to fetch leave balances
    $query = "
        SELECT 
            leave_types.name AS leave_type_name, 
            leave_balances.balance 
        FROM leave_balances
        INNER JOIN leave_types ON leave_balances.leave_type_id = leave_types.id
        WHERE leave_balances.emp_no = ?
    ";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Database error: " . $conn->error);
    }

    $stmt->bind_param('s', $emp_no);
    $stmt->execute();
    $result = $stmt->get_result();

    $balances = [];
    while ($row = $result->fetch_assoc()) {
        $balances[$row['leave_type_name']] = (int)$row['balance'];
    }

    // Close statement
    $stmt->close();

    // Return JSON response
    echo json_encode(['status' => 'success', 'data' => $balances]);
    exit;
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error', 
        'message' => 'An error occurred.', 
        'error' => $e->getMessage()
    ]);
    exit;
}
?>
