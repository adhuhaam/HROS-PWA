<?php
include_once '../common/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (!isset($conn)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit;
}

$emp_no = isset($_GET['emp_no']) ? trim($_GET['emp_no']) : '';

if (empty($emp_no)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Employee number is required.']);
    exit;
}

try {
    $emp_no = mysqli_real_escape_string($conn, $emp_no);

    // ✅ Include emergency_contact_number and emergency_contact_name in the query
    $query = "
        SELECT emp_no, name, department, designation, persent_address, contact_number, 
               emp_email, date_of_join, basic_salary,
               emergency_contact_number, emergency_contact_name
        FROM employees 
        WHERE emp_no = ?
    ";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Database error: " . $conn->error);
    }

    $stmt->bind_param("s", $emp_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Employee not found.']);
        $stmt->close();
        $conn->close();
        exit;
    }

    $employee = $result->fetch_assoc();

    $response = [
        'status' => 'success',
        'data' => [
            'emp_no' => $employee['emp_no'],
            'name' => $employee['name'] ?? 'N/A',
            'department' => $employee['department'] ?? 'N/A',
            'persentaddress' => $employee['persent_address'] ?? 'N/A',
            'designation' => $employee['designation'] ?? 'N/A',
            'contact_number' => $employee['contact_number'] ?? 'N/A',
            'email' => $employee['emp_email'] ?? 'N/A',
            'date_of_join' => $employee['date_of_join'] ?? 'N/A',
            'basic_salary' => $employee['basic_salary'] ?? '0.00',
            'emergency_contact_number' => $employee['emergency_contact_number'] ?? '',
            'emergency_contact_name' => $employee['emergency_contact_name'] ?? ''
        ]
    ];

    echo json_encode($response);

    $stmt->close();
    $conn->close();
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred.',
        'error' => $e->getMessage()
    ]);
    exit;
}
