<?php
include_once '../common/db.php'; // Include database connection
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emp_no = $_POST['employee_id'] ?? null;
    $leave_type_id = $_POST['leave_type_id'] ?? null;

    // Validate required fields
    if (!$emp_no || !$leave_type_id) {
        echo json_encode(['status' => 'error', 'message' => 'Employee ID and Leave Type ID are required.']);
        exit;
    }

    // Fetch employee details
    $employee_query = $conn->prepare("SELECT * FROM employees WHERE emp_no = ?");
    $employee_query->bind_param("s", $emp_no);
    $employee_query->execute();
    $employee = $employee_query->get_result()->fetch_assoc();

    if (!$employee) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid employee.']);
        exit;
    }

    // Calculate probation and service years
    $join_date = new DateTime($employee['date_of_join']);
    $current_date = new DateTime();
    $service_years = $join_date->diff($current_date)->y;
    $level = $employee['level']; // senior or junior
    $nationality = $employee['nationality'];

    // Fetch leave balance
    $balance_query = $conn->prepare("SELECT balance FROM leave_balances WHERE emp_no = ? AND leave_type_id = ?");
    $balance_query->bind_param("si", $emp_no, $leave_type_id);
    $balance_query->execute();
    $balance_result = $balance_query->get_result();
    $balance = $balance_result->fetch_assoc()['balance'] ?? 0;

    // Cap leave forwarding balance to 120 days
    if ($balance > 120) {
        $balance = 120;
    }

    // Initialize eligibility response
    $response = ['status' => 'error', 'eligible' => false, 'message' => ''];

    // Apply eligibility rules based on nationality
    switch ($nationality) {
        case 'MALDIVIAN':
            if ($service_years >= 1) {
                $response['eligible'] = true;
                $response['message'] = 'Eligible for annual leave.';
            } else {
                $response['message'] = 'Not eligible: still in probation period (Complete 1 year from date of join!).';
            }
            break;

        case 'INDIAN':
        case 'SRI LANKAN':
            if ($level === 'senior') {
                if ($service_years >= 1) {
                    $response['eligible'] = true;
                    $response['message'] = 'Eligible for annual leave.';
                } else {
                    $response['message'] = 'Not eligible: senior staff require at least 1 year of service.';
                }
            } elseif ($level === 'junior') {
                if ($service_years >= 2) {
                    $response['eligible'] = true;
                    $response['message'] = $service_years > 2
                        ? 'Eligible for annual leave.'
                        : 'Eligible for 60 days after 2 years probation.';
                } else {
                    $response['message'] = 'Not eligible: junior staff require 2 years probation.';
                }
            }
            break;

        case 'BANGLADESHI':
            if ($service_years >= 2) {
                $response['eligible'] = true;
                $response['message'] = 'Eligible for annual leave.';
            } else {
                $response['message'] = 'Not eligible: requires to complete 2 years probation.';
            }
            break;

        case 'NEPALESE':
            if ($service_years >= 2) {
                $response['eligible'] = true;
                $response['message'] = 'Eligible for annual leave.';
            } elseif ($service_years >= 1) {
                $response['eligible'] = true;
                $response['message'] = 'Eligible for annual leave.';
            } else {
                $response['message'] = 'Not eligible: still in probation period.';
            }
            break;

        default:
            $response['message'] = 'Nationality not eligible for Annual Leave.';
    }

    // Check leave balance
    if ($response['eligible'] && $balance <= 0) {
        $response['eligible'] = false;
        $response['message'] = 'Not eligible: insufficient leave balance.';
    } elseif ($response['eligible']) {
        $response['status'] = 'success';
        $response['message'] .= ' Remaining Leave balance: ' . $balance . ' days.';
    }

    // Return JSON response
    echo json_encode($response);
}
?>
