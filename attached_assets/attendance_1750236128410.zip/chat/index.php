<?php
header('Content-Type: application/json');
include '../common/db.php';

$emp_no = $_GET['emp_no'] ?? '';
$hr_id = '1'; // HR user_id fixed
$hr_type = 'hr';

// ✅ Validate input
if (!$emp_no) {
    echo json_encode([
        'status' => 'error',
        'message' => 'emp_no is required'
    ]);
    exit;
}

// ✅ Prepare SQL query
$stmt = $conn->prepare("
    SELECT * FROM chat_messages
    WHERE 
        (sender_id = ? AND sender_type = 'employee' AND receiver_id = ? AND receiver_type = ?)
     OR (sender_id = ? AND sender_type = ? AND receiver_id = ? AND receiver_type = 'employee')
    ORDER BY created_at ASC
");

$sender_type = 'employee';
$stmt->bind_param(
    "ssssss",
    $emp_no, $hr_id, $hr_type,
    $hr_id, $hr_type, $emp_no
);

$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = [
        'id' => $row['id'],
        'from' => $row['sender_type'], // 'employee' or 'hr'
        'sender_id' => $row['sender_id'],
        'receiver_id' => $row['receiver_id'],
        'message' => $row['message'],
        'is_read' => $row['is_read'],
        'timestamp' => $row['created_at']
    ];
}

// ✅ Return as JSON
echo json_encode([
    'status' => 'success',
    'emp_no' => $emp_no,
    'messages' => $messages
], JSON_UNESCAPED_UNICODE);
