<?php
// Include DB connection
include '../common/db.php';

// Set response headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Retrieve emp_no from GET parameters
$emp_no = $_GET['emp_no'] ?? '';

if (empty($emp_no)) {
    http_response_code(400); // Bad Request
    echo json_encode([
        'status' => 'error',
        'message' => 'Employee number is required.'
    ]);
    exit;
}

try {
    // SQL query to fetch leave records for the employee
    $query = "
        SELECT 
            lr.id AS leave_id,
            lt.name AS leave_type,
            lr.start_date,
            lr.end_date,
            lr.num_days,
            lr.remarks,
            lr.status,
            lr.applied_date
        FROM leave_records lr
        INNER JOIN leave_types lt ON lr.leave_type_id = lt.id
        WHERE lr.emp_no = ?
        ORDER BY lr.applied_date DESC
    ";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("SQL prepare failed: " . $conn->error);
    }

    $stmt->bind_param('s', $emp_no);
    $stmt->execute();
    $result = $stmt->get_result();

    $leaves = [];
    while ($row = $result->fetch_assoc()) {
        $leaves[] = [
            'leave_id'      => $row['leave_id'],
            'leave_type'    => $row['leave_type'],
            'start_date'    => $row['start_date'],
            'end_date'      => $row['end_date'],
            'num_days'      => (int)$row['num_days'],
            'remarks'       => $row['remarks'] ?? null,
            'status'        => $row['status'],
            'applied_date'  => $row['applied_date']
        ];
    }

    http_response_code(200); // OK
    echo json_encode([
        'status' => 'success',
        'data' => $leaves,
        'message' => empty($leaves) ? 'No leave records found.' : null
    ]);

    $stmt->close();
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred while fetching leave records.',
        'error' => $e->getMessage()
    ]);
    exit;
}
?>
