<?php
echo "API is working!";
