<?php
header('Content-Type: application/json');
include 'db.php';

$sectionsRes = $conn->query("SELECT * FROM handbook_sections ORDER BY sort_order ASC, section_number ASC");

$handbook = [];

while ($section = $sectionsRes->fetch_assoc()) {
    $sectionId = $section['id'];

    $subsectionsStmt = $conn->prepare("
        SELECT id, subsection_number, title 
        FROM handbook_subsections 
        WHERE section_id = ? 
        ORDER BY sort_order ASC, subsection_number ASC
    ");
    $subsectionsStmt->bind_param("i", $sectionId);
    $subsectionsStmt->execute();
    $subResult = $subsectionsStmt->get_result();

    $subsections = [];
    while ($sub = $subResult->fetch_assoc()) {
        $detailsStmt = $conn->prepare("
            SELECT detail_number, title, content, image_path 
            FROM handbook_details 
            WHERE subsection_id = ? 
            ORDER BY sort_order ASC, detail_number ASC
        ");
        $detailsStmt->bind_param("i", $sub['id']);
        $detailsStmt->execute();
        $detailsRes = $detailsStmt->get_result();

        $details = [];
        while ($d = $detailsRes->fetch_assoc()) {
            $details[] = [
                'detail_number' => $d['detail_number'],
                'title'         => $d['title'],
                'content'       => $d['content'],
                'image'         => !empty($d['image_path']) ? getFullUrl($d['image_path']) : null
            ];
        }

        $subsections[] = [
            'subsection_number' => $sub['subsection_number'],
            'title'              => $sub['title'],
            'details'            => $details
        ];
    }

    $handbook[] = [
        'section_number' => $section['section_number'],
        'title'          => $section['title'],
        'subsections'    => $subsections
    ];
}

echo json_encode([
    'status' => 'success',
    'data' => $handbook
]);

function getFullUrl($path) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $base = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    return "$protocol://$host$base/$path";
}
?>
