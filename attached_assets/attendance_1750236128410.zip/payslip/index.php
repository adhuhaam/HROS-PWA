<?php
// Include database connection
include_once '../common/db.php';

// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Get parameters from the request
$emp_no = $_GET['emp_no'] ?? '';
$date = $_GET['date'] ?? '';

if (empty($emp_no)) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Employee number is required.']);
    exit;
}

try {
    if (empty($date)) {
        // Fetch all months of payslips
        $query = "
            SELECT DISTINCT DATE_FORMAT(date, '%Y-%m') AS month, 
                   DATE_FORMAT(date, '%b %Y') AS display_date,
                   SUM(basic_salary + service_allowance + island_allowance + attendance_allowance +
                       salary_arrear_other + safety_allowance + pump_brick_batching + food_and_tea + 
                       long_term_service_allowance + living_allowance + ot + ot_arrears + phone_allowance + 
                       petrol_allowance + pension) AS total_income,
                   SUM((SELECT SUM(other_deduction + salary_advance + loan + pension + 
                                   medical_deduction + no_pay + late)
                        FROM salary_deductions
                        WHERE salary_income.emp_no = salary_deductions.emp_no
                          AND DATE_FORMAT(salary_income.date, '%Y-%m') = DATE_FORMAT(salary_deductions.date, '%Y-%m'))
                   ) AS total_deductions,
                   SUM(basic_salary + service_allowance + island_allowance + attendance_allowance +
                       salary_arrear_other + safety_allowance + pump_brick_batching + food_and_tea + 
                       long_term_service_allowance + living_allowance + ot + ot_arrears + phone_allowance + 
                       petrol_allowance + pension) -
                   SUM((SELECT SUM(other_deduction + salary_advance + loan + pension + 
                                   medical_deduction + no_pay + late)
                        FROM salary_deductions
                        WHERE salary_income.emp_no = salary_deductions.emp_no
                          AND DATE_FORMAT(salary_income.date, '%Y-%m') = DATE_FORMAT(salary_deductions.date, '%Y-%m'))
                   ) AS net_salary
            FROM salary_income
            WHERE emp_no = ?
            GROUP BY DATE_FORMAT(date, '%Y-%m')
            ORDER BY date DESC";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $emp_no);
        $stmt->execute();
        $result = $stmt->get_result();

        $months = [];
        while ($row = $result->fetch_assoc()) {
            $months[] = [
                'month' => $row['month'],
                'display_date' => $row['display_date'],
                'net_salary' => $row['net_salary'] ?? 0,
            ];
        }
        $stmt->close();

        echo json_encode(['status' => 'success', 'data' => $months]);
    } else {
        // Fetch details for a specific month
        // Query for salary income
        $income_query = "
            SELECT 
                basic_salary AS 'Basic Salary',
                service_allowance AS 'Service Allowance',
                island_allowance AS 'Island Allowance',
                attendance_allowance AS 'Attendance Allowance',
                salary_arrear_other AS 'Salary Arrear/Other',
                safety_allowance AS 'Safety Allowance',
                pump_brick_batching AS 'Pump/Brick/Batching Allowance',
                food_and_tea AS 'Food and Tea',
                long_term_service_allowance AS 'Long Term Service Allowance',
                living_allowance AS 'Living Allowance',
                ot AS 'Overtime',
                ot_arrears AS 'OT Arrears',
                phone_allowance AS 'Phone Allowance',
                petrol_allowance AS 'Petrol Allowance',
                pension AS 'Pension'
            FROM salary_income 
            WHERE emp_no = ? AND DATE_FORMAT(date, '%Y-%m') = ?";
        $income_stmt = $conn->prepare($income_query);
        $income_stmt->bind_param('ss', $emp_no, $date);
        $income_stmt->execute();
        $income_result = $income_stmt->get_result();
        $income = $income_result->fetch_assoc();
        $income_stmt->close();

        // Query for salary deductions
        $deduction_query = "
            SELECT 
                other_deduction AS 'Other Deductions',
                salary_advance AS 'Salary Advance',
                loan AS 'Loan',
                pension AS 'Pension',
                medical_deduction AS 'Medical Deduction',
                no_pay AS 'No Pay',
                late AS 'Late Deductions'
            FROM salary_deductions 
            WHERE emp_no = ? AND DATE_FORMAT(date, '%Y-%m') = ?";
        $deduction_stmt = $conn->prepare($deduction_query);
        $deduction_stmt->bind_param('ss', $emp_no, $date);
        $deduction_stmt->execute();
        $deduction_result = $deduction_stmt->get_result();
        $deductions = $deduction_result->fetch_assoc();
        $deduction_stmt->close();

        if (!$income || !$deductions) {
            http_response_code(404); // Not Found
            echo json_encode(['status' => 'error', 'message' => 'No data found for the provided employee number and date.']);
            exit;
        }

        // Calculate total income and deductions
        $total_income = array_sum($income);
        $total_deductions = array_sum($deductions);

        // Calculate net salary
        $net_salary = $total_income - $total_deductions;

        // Return the data
        echo json_encode([
            'status' => 'success',
            'data' => [
                'income' => $income,
                'total_income' => $total_income,
                'deductions' => $deductions,
                'total_deductions' => $total_deductions,
                'net_salary' => $net_salary
            ]
        ]);
    }
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'An error occurred.', 'error' => $e->getMessage()]);
    exit;
}
