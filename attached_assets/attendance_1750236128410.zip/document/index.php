<?php
include_once '../common/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$emp_no = $_GET['emp_no'] ?? '';
if (empty($emp_no)) {
    echo json_encode(['status' => 'error', 'message' => 'Employee number is required.']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT doc_type, front_file_name, back_file_name, photo_file_name FROM employee_documents WHERE emp_no = ?");
    $stmt->bind_param("s", $emp_no);
    $stmt->execute();
    $result = $stmt->get_result();

    $documents = [];
    while ($row = $result->fetch_assoc()) {
        $documents[] = $row;
    }

    echo json_encode(['status' => 'success', 'data' => $documents]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
