<?php
// Include database connection
include_once '../common/db.php'; // Adjust the path as per your project structure

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Get the emp_no from query parameters
$emp_no = $_GET['emp_no'] ?? '';

if (empty($emp_no)) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Employee number is required.']);
    exit;
}

try {
    // Query to fetch warnings for the employee
    $query = "SELECT id, emp_no, problem, status, created_at 
              FROM warnings 
              WHERE emp_no = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    $stmt->bind_param("s", $emp_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'No warnings found for this employee.']);
        $stmt->close();
        exit;
    }

    // Fetch warnings
    $warnings = [];
    while ($row = $result->fetch_assoc()) {
        $warnings[] = $row;
    }

    echo json_encode(['status' => 'success', 'data' => $warnings]);
    $stmt->close();
    exit;

} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'An error occurred.', 'error' => $e->getMessage()]);
    exit;
}
