<?php
// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Include the database connection
include_once '../common/db.php';

// Check if the database connection exists
if (!isset($conn)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection not established.']);
    exit;
}

// Get the input data
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validate input
if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Username and password are required.']);
    exit;
}

try {
    // Fetch user details from users table, joined with employees
    $query = "SELECT emp_no, username, password, staff_name
              FROM users 
              WHERE username = ?";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Failed to prepare the statement: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid username or password.']);
        $stmt->close();
        exit;
    }

    $user = $result->fetch_assoc();

    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid username or password.']);
        $stmt->close();
        exit;
    }

    // Login successful
    echo json_encode([
        'status' => 'success',
        'message' => 'Login successful.',
        'data' => [
            'emp_no' => $user['emp_no'],
            'staff_name' => $user['staff_name'],
            'username' => $user['username']
        ]
    ]);

    $stmt->close();
    $conn->close();
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred.',
        'error' => $e->getMessage()
    ]);
    exit;
}
