<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

include '../common/db.php';

$emp_no = $_GET['emp_no'] ?? null;
$month  = isset($_GET['month']) ? (int)$_GET['month'] : null;
$year   = isset($_GET['year']) ? (int)$_GET['year'] : null;

if (!$emp_no || !$month || !$year) {
    echo json_encode(['status' => 'error', 'message' => 'emp_no, month, and year are required.']);
    exit;
}

// Calculate date range: 20th current month to 21st next month
$startDate = date("Y-m-d", strtotime("$year-$month-20"));
$nextMonth = $month + 1;
$nextYear = $nextMonth > 12 ? $year + 1 : $year;
$nextMonth = $nextMonth > 12 ? 1 : $nextMonth;
$endDate = date("Y-m-d", strtotime("$nextYear-$nextMonth-21"));

// Prepare SQL
$sql = "SELECT record_id, emp_no, month, year, day, day_type, shift, present_absent, 
               work_in, work_out, remarks, island_name, site_name, status
        FROM attendance_records
        WHERE emp_no = ?
        AND DATE(CONCAT(year, '-', LPAD(month, 2, '0'), '-', LPAD(day, 2, '0')))
            BETWEEN ? AND ?
        ORDER BY year DESC, month DESC, day DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $emp_no, $startDate, $endDate);
$stmt->execute();
$result = $stmt->get_result();

$records = [];
while ($row = $result->fetch_assoc()) {
    $records[] = $row;
}

echo json_encode([
    'status' => 'success',
    'from' => $startDate,
    'to' => $endDate,
    'count' => count($records),
    'records' => $records
]); //GET /index.php?emp_no=5016&month=5&year=2025

