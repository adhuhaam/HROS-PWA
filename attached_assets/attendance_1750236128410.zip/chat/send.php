<?php
header('Content-Type: application/json');
include '../common/db.php';

$emp_no = $_POST['emp_no'] ?? '';
$message = trim($_POST['message'] ?? '');
$receiver_id = '1'; // HR user_id
$receiver_type = 'hr';

// ✅ Validation
if (empty($emp_no) || empty($message)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'emp_no and message are required'
    ]);
    exit;
}

// ✅ Insert message
$stmt = $conn->prepare("INSERT INTO chat_messages 
    (sender_id, sender_type, receiver_id, receiver_type, message) 
    VALUES (?, 'employee', ?, ?, ?)");

if (!$stmt) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Statement preparation failed'
    ]);
    exit;
}

$stmt->bind_param("ssss", $emp_no, $receiver_id, $receiver_type, $message);

if ($stmt->execute()) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Message sent'
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $stmt->error
    ]);
}
