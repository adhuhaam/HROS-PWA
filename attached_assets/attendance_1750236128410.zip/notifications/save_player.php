<?php
header('Content-Type: application/json');

// Load shared DB connection
require_once __DIR__ . '/../common/db.php';

$input = json_decode(file_get_contents("php://input"), true);
$emp_no = $input['emp_no'] ?? null;
$player_id = $input['player_id'] ?? null;

if (!$emp_no || !$player_id) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Missing emp_no or player_id'
    ]);
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE employees SET player_id = ? WHERE emp_no = ?");
    $stmt->bind_param("ss", $player_id, $emp_no);
    $stmt->execute();

    echo json_encode([
        'status' => 'success',
        'message' => 'Player ID saved successfully'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
