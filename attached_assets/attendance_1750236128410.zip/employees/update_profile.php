<?php
include '../common/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// ✅ Read POST data
$emp_no = $_POST['emp_no'] ?? '';
$contact_number = $_POST['contact_number'] ?? '';
$email = $_POST['email'] ?? '';
$persent_address = $_POST['persent_address'] ?? '';
$emergency_contact_number = $_POST['emergency_contact_number'] ?? '';
$emergency_contact_name = $_POST['emergency_contact_name'] ?? '';

// ✅ Validate input
if (!$emp_no || !$contact_number || !$email || !$persent_address || !$emergency_contact_number || !$emergency_contact_name) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
    exit;
}

try {
    // ✅ Prepare SQL update with additional fields
    $stmt = $conn->prepare("
        UPDATE employees 
        SET 
            contact_number = ?, 
            emp_email = ?, 
            persent_address = ?, 
            emergency_contact_number = ?, 
            emergency_contact_name = ? 
        WHERE emp_no = ?
    ");
    
    $stmt->bind_param("ssssss", 
        $contact_number, 
        $email, 
        $persent_address, 
        $emergency_contact_number, 
        $emergency_contact_name, 
        $emp_no
    );

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Update failed.']);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred while updating.',
        'error' => $e->getMessage()
    ]);
}
?>
