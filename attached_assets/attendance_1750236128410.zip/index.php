<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get the requested path from the query
$path = isset($_GET['path']) ? explode('/', trim($_GET['path'], '/')) : [];

// List of allowed modules
$routes = [
    'auth' => 'auth/index.php',
    'leaves' => 'leaves/index.php',
    'loans' => 'loans/index.php',
    'cards' => 'cards/index.php',
    'notifications' => 'notifications/index.php',
    'attendance' => 'attendance/index.php',
    'salary' => 'salary/index.php',
    'profile' => 'profile/index.php',
    'documents' => 'documents/index.php',
];

// Route the request
if (isset($path[0]) && array_key_exists($path[0], $routes)) {
    include $routes[$path[0]];
} else {
    http_response_code(404);
    echo json_encode(["error" => "You lost? This is not a good place to be, Shu shu!!"]);
    exit;
}
